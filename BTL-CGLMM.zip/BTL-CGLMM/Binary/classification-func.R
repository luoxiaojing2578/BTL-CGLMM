# Function(Simulation)

library(Rcpp)
library(brms)
library(rstan)
rstan_options(auto_write = TRUE)

simi.mat <- function(dis.mat) {
  n <- ncol(dis.mat)
  D2 <- dis.mat^2
  I <- diag(1, n)
  II <- array(1, c(n,n))
  K <- -0.5 * (I - II/n) %*% D2 %*% (I - II/n)
  ev <- eigen(K)
  v <- ev$vectors
  e <- abs(ev$values) + 2e-8
  K <- v %*% diag(e) %*% t(v)
  K
}

construct_taxa_structure <- function(X, m = "bray") {
  otu = otu_table(X, taxa_are_rows = FALSE)
  dis.taxa = as.matrix(distance(otu, method = m, type = "taxa"))
  K.taxa = simi.mat(dis.taxa) 
  node1 = node2 = w = NULL
  for (i in 1:(ncol(K.taxa)-1)) {
    for (j in (i+1):ncol(K.taxa)) {
      if(abs(K.taxa[i,j]) > 0.18) {
        node1 = c(node1, i)
        node2 = c(node2, j)
        w = c(w, K.taxa[i,j])
      }
    }
  }
  list(K.taxa = K.taxa, node1 = node1, node2 = node2, w = sqrt(abs(w)))
}

construct_sample_kernel <- function(Z_target, Z_source, m = "bray") {
  X_all <- rbind(Z_target, do.call(rbind, Z_source))
  otu_all <- otu_table(exp(X_all) / rowSums(exp(X_all)), taxa_are_rows = FALSE)
  dis.sample.all <- as.matrix(distance(otu_all, method = m, type = "sample"))
  K.sample.all <- simi.mat(dis.sample.all) 
  return(K.sample.all)
}

### Generate Data
## Target data generation(homogeneous source)
generate_target_data_tg <- function(n, m, snr, noise_sd = 1.6, rho_sample = 0.4, seed = 2025) {
  set.seed(seed)
  np <- snr * m
  gammatrue <- rep(1, m)
  true_index <- seq(18, 28, by = 2)
  b1 <- c(2.0800, -1.1600, -2.1200)
  b2 <- c(1.5000, -0.8600, 0.56)
  b <- rep(0, m)
  b[true_index[seq(1, length(true_index), 2)]] <- b1
  b[true_index[seq(2, length(true_index), 2)]] <- b2
  b[(m - np):(m - 1)] <- rnorm(np, 0, 0.2)
  b[m] <- -sum(b[1:(m - 1)])
  theta <- rep(0, m)
  theta[true_index] <- log(0.5 * m)
  beta <- gammatrue * b
  
  sigmaX = 1
  s <- diag(m) * sigmaX
  # For Target
  Xcor <- matrix(0, m, m)
  for (i in seq(18, 26, by = 2)) {
    for (j in seq(i + 2, 28, by = 2)) {
      Xcor[i, j] <- 0.75 - 0.015 * abs(i - j)
    }
  }
  for (i in (m - np):(m - 1)) {
    for (j in (m - np + 1):m) {
      Xcor[i, j] <- 0.25 - 0.00015 * abs(i - j)
    }
  }
  Xcor <- Xcor + t(Xcor) + diag(m)
  Sigma = s %*% Xcor %*% s
  # For Source
  Xcors <- matrix(0, m, m)
  for (i in seq(18, 26, by = 2)) {
    for (j in seq(i + 2, 28, by = 2)) {
      Xcors[i, j] <- 0.75 - 0.015 * abs(i - j)
    }
  }
  for (i in (m - np):(m - 1)) {
    for (j in (m - np + 1):m) {
      Xcors[i, j] <- 0.25 - 0.00015 * abs(i - j) 
    }
  }
  Xcors <- Xcors + t(Xcors) + diag(m)
  Sigmas = s %*% Xcors %*% s
  
  X <- mvrnorm(n, theta, Sigma)
  x <- exp(X)
  X <- x / rowSums(x)
  Z <- log(X)
  Sigma_sample <- rho_sample ^ abs(outer(1:n, 1:n, "-"))
  L <- t(chol(Sigma_sample + 1e-6 * diag(n))) 
  z <- rnorm(n)
  u <- L %*% z
  epsilon <- rnorm(n, 0, noise_sd)
  eta <- as.vector(Z %*% beta + u + epsilon) 
  p_y <- 1 / (1 + exp(-eta))
  y <- rbinom(n, size = 1, prob = p_y)
  
  list(y = as.vector(y), Z = Z, X = X, beta = beta, theta = theta,
       Sigma = Sigma, Sigmas = Sigmas, u = u, Sigma_sample = Sigma_sample,np = np, true_index = true_index)
}

# ## Target data generation(heterogeneous source) 
# generate_target_data_yg <- function(n, m, snr, noise_sd = 1.6, rho_sample = 0.4, seed = 2025) {
#   set.seed(seed)
#   np <- snr * m
#   gammatrue <- rep(1, m)
#   true_index <- seq(18, 28, by = 2)
#   b1 <- c(2.0800, -1.1600, -2.1200)
#   b2 <- c(1.5000, -0.8600, 0.56)
#   b <- rep(0, m)
#   b[true_index[seq(1, length(true_index), 2)]] <- b1
#   b[true_index[seq(2, length(true_index), 2)]] <- b2
#   b[(m - np):(m - 1)] <- rnorm(np, 0, 0.2)
#   b[m] <- -sum(b[1:(m - 1)])
#   theta <- rep(0, m)
#   theta[true_index] <- log(0.5 * m)
#   beta <- gammatrue * b
#   
#   sigmaX = 1
#   s <- diag(m) * sigmaX
#   # For Target
#   Xcor <- matrix(0, m, m)
#   for (i in seq(18, 26, by = 2)) {
#     for (j in seq(i + 2, 28, by = 2)) {
#       Xcor[i, j] <- 0.75 - 0.015 * abs(i - j)
#     }
#   }
#   for (i in (m - np):(m - 1)) {
#     for (j in (m - np + 1):m) {
#       Xcor[i, j] <- 0.25 - 0.00015 * abs(i - j)
#     }
#   }
#   Xcor <- Xcor + t(Xcor) + diag(m)
#   Sigma = s %*% Xcor %*% s
#   # For Source
#   Xcors <- matrix(0, m, m)
#   for (i in seq(18, 26, by = 2)) {
#     for (j in seq(i + 2, 28, by = 2)) {
#       Xcor[i,j] <- 0.75 * exp(-0.1 * abs(i-j)) 
#     }
#   }
#   for (i in (m - np):(m - 1)) {
#     for (j in (m - np + 1):m) {
#       Xcor[i,j] <- 0.25 * exp(-0.01 * abs(i-j))  
#     }
#   }
#   Xcors <- Xcors + t(Xcors) + diag(m)
#   Sigmas = s %*% Xcors %*% s
#   
#   X <- mvrnorm(n, theta, Sigma)
#   x <- exp(X)
#   X <- x / rowSums(x)
#   Z <- log(X)
#   Sigma_sample <- rho_sample ^ abs(outer(1:n, 1:n, "-"))
#   L <- t(chol(Sigma_sample + 1e-6 * diag(n))) 
#   z <- rnorm(n)
#   u <- L %*% z
#   epsilon <- rnorm(n, 0, noise_sd)
#   eta <- as.vector(Z %*% beta + u + epsilon) 
#   p_y <- 1 / (1 + exp(-eta))
#   y <- rbinom(n, size = 1, prob = p_y)
#   
#   list(y = as.vector(y), Z = Z, X = X, beta = beta, theta = theta,
#        Sigma = Sigma, Sigmas = Sigmas, u = u, Sigma_sample = Sigma_sample,np = np, true_index = true_index)
# }

## Source data generation 
generate_source_data <- function(beta_target, theta, Sigmas, np, h, n_source, sig.delta, noise_sd = 1.6, rho_sample = 0.4, seed = 2025) {
  set.seed(seed)
  m <- length(beta_target)
  small_effect_idx <- (m - np):(m - 1) 
  candidate_idx <- setdiff(1:m, small_effect_idx) 
  pos_idx <- sample(candidate_idx, h/2, replace = FALSE)
  remaining_idx <- setdiff(candidate_idx, pos_idx)
  neg_idx <- sample(remaining_idx, h/2, replace = FALSE)
  beta_source <- beta_target
  beta_source[pos_idx] <- beta_source[pos_idx] + sig.delta
  beta_source[neg_idx] <- beta_source[neg_idx] - sig.delta
  beta_source <- as.numeric(beta_source)  
  X_source = MASS::mvrnorm(n_source, theta, Sigmas)
  x_source = exp(X_source)
  x_source = x_source / rowSums(x_source)
  x_log_source = log(x_source)
  Sigma_sample_source <- rho_sample ^ abs(outer(1:n_source, 1:n_source, "-"))
  L_source <- t(chol(Sigma_sample_source + 1e-6 * diag(n_source))) 
  z_source <- rnorm(n_source)
  u_source <- L_source %*% z_source
  epsilon_source <- rnorm(n_source, 0, noise_sd)
  eta_source <- as.vector(x_log_source %*% beta_source + u_source +epsilon_source)      
  p_y_source <- 1 / (1 + exp(-eta_source))
  y_source <- rbinom(n_source, size = 1, prob = p_y_source)
  
  list(y = as.vector(y_source), Z = x_log_source, beta = beta_source)
}

### Mothods
## BTL-CGLMM
BTL_CGLMM <- function(target_data, source_data, 
                                        m,
                                        alpha = 1,
                                        stan_file = "Classification_BTL_CGLMM.stan",
                                        iter = 2000,
                                        chains = 2,
                                        adapt_delta = 0.95,
                                        max_treedepth = 10,
                                        seed = 2025) {
  structure_info <- construct_taxa_structure(X = target_data$X)
  K.taxa <- structure_info$K.taxa
  node1 <- structure_info$node1
  node2 <- structure_info$node2
  w <- structure_info$w
  Z_sources <- lapply(source_data, function(x) x$Z)
  y_sources <- lapply(source_data, function(x) x$y)
  K.sample.all <- construct_sample_kernel(target_data$Z, Z_sources)
  n_target <- nrow(target_data$Z)
  n_sources <- sapply(source_data, function(x) nrow(x$Z))
  total_source <- sum(n_sources)
  stan_data <- list(
    N = n_target,
    Y = as.vector(target_data$y),
    N_source = total_source,
    Y_source = unlist(y_sources),
    K = m + 1,
    X = cbind(1, target_data$Z),
    X_source = cbind(1, do.call(rbind, Z_sources)),
    Kc = m,
    Kscales = m,
    hs_df = 3,
    hs_df_global = 1,
    hs_df_slab = 4,
    hs_scale_global = 0.5,
    hs_scale_slab = 1,
    N_1 = n_target + total_source,
    M_1 = 1,
    J_1 = 1:n_target,
    J_1_source = (n_target + 1):(n_target + total_source),
    Lcov_1 = chol(K.sample.all + diag(1e-6, n_target + total_source)),
    Z_1_1 = rep(1, n_target),
    Z_1_1_source = rep(1, total_source),
    alpha = alpha,
    prior_only = 0,
    ln = length(node1),
    node1 = node1,
    node2 = node2,
    w = w
  )
  
  fit <- sampling(
    object = precompiled_models[[stan_file]],  
    data = stan_data,
    iter = iter,
    chains = chains,
    control = list(adapt_delta = adapt_delta, max_treedepth = max_treedepth),
    seed = seed
  )
  
  return(fit)
}

## Adaptive BTL-CGLMM
Adaptive_BTL_CGLMM <- function(target_data, source_data, 
                                          m,
                                          stan_file = "Classification_Adaptive_BTL_CGLMM.stan",
                                          iter = 2000,
                                          chains = 2,
                                          adapt_delta = 0.95,
                                          max_treedepth = 10,
                                          seed = 2025) {
  structure_info <- construct_taxa_structure(X = target_data$X)
  K.taxa <- structure_info$K.taxa
  node1 <- structure_info$node1
  node2 <- structure_info$node2
  w <- structure_info$w
  Z_sources <- lapply(source_data, function(x) x$Z)
  y_sources <- lapply(source_data, function(x) x$y)
  K.sample.all <- construct_sample_kernel(target_data$Z, Z_sources)
  n_target <- nrow(target_data$Z)
  n_sources <- sapply(source_data, function(x) nrow(x$Z))
  total_source <- sum(n_sources)
  
  stan_data <- list(
    N = n_target,
    Y = as.vector(target_data$y),
    N_source = total_source,
    Y_source = unlist(y_sources),
    K = m + 1,
    X = cbind(1, target_data$Z),
    X_source = cbind(1, do.call(rbind, Z_sources)),
    Kc = m,
    Kscales = m,
    hs_df = 3,
    hs_df_global = 1,
    hs_df_slab = 4,
    hs_scale_global = 0.5,
    hs_scale_slab = 1,
    N_1 = n_target + total_source,
    M_1 = 1,
    J_1 = 1:n_target,
    J_1_source = (n_target + 1):(n_target + total_source),
    Lcov_1 = chol(K.sample.all + diag(1e-6, n_target + total_source)),
    Z_1_1 = rep(1, n_target),
    Z_1_1_source = rep(1, total_source),
    prior_only = 0,
    ln = length(node1),
    node1 = node1,
    node2 = node2,
    w = w
  )
  
  fit <- sampling(
    object = precompiled_models[[stan_file]],  
    data = stan_data,
    iter = iter,
    chains = chains,
    control = list(adapt_delta = adapt_delta, max_treedepth = max_treedepth),
    seed = seed   
  )
  
  return(fit)
}

### Evaluation
calculate_loo_preds_classification <- function(log_lik, y_rep) {
  n <- ncol(log_lik)  
  psis_object <- psis(log_lik)
  loo_preds <- sapply(1:n, function(i) {
    if (psis_object$diagnostics$pareto_k[i] < 0.7) {
      weights <- exp(psis_object$log_weights[, i])
      weights <- weights / sum(weights)
      sum(y_rep[, i] * weights)
    } else {
      mean(y_rep[, i])
    }
  })
  return(loo_preds)
}

calculate_loo_metrics_classification <- function(y, loo_probs) {
  n <- length(y)
  K <- ncol(loo_probs)
  
  if (K == 2) {
    mu <- loo_probs[, 2]   
    logL <- dbinom(y, size = 1, prob = mu, log = TRUE)
    deviance <- -2 * sum(logL, na.rm = TRUE)
  } else {
    log_probs <- sapply(1:n, function(i) loo_probs[i, y[i] + 1])
    deviance <- -2 * sum(log(log_probs + 1e-12))
  }
  
  if (K == 2) {
    mu <- loo_probs[, 2]
    mse <- mean((y - mu)^2, na.rm = TRUE)
    mae <- mean(abs(y - mu), na.rm = TRUE)
  } else {
    y_onehot <- matrix(0, nrow = n, ncol = K)
    for (i in 1:n) y_onehot[i, y[i] + 1] <- 1
    mse <- mean(rowSums((loo_probs - y_onehot)^2))
    mae <- mean(rowSums(abs(loo_probs - y_onehot)))
  }
  
  if (K == 2) {
    pred_class <- ifelse(loo_probs[, 2] >= 0.5, 1, 0)
    misclassification <- mean(pred_class != y)
  } else {
    pred_class <- apply(loo_probs, 1, which.max) - 1
    misclassification <- mean(pred_class != y)
  }
  
  list(
    deviance = deviance,
    mse = mse,
    mae = mae,
    misclassification = misclassification
  )
}

