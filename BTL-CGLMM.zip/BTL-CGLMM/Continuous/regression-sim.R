# Simulation

library(MASS)
library(phyloseq)
library(openxlsx)
library(loo)
library(data.table)
library(rstan)
source("regression-func.R")

stan_model_files <- c(
  "Regression_BTL_CGLMM.stan", # BTL-CGLMM
  "Regression_Adaptive_BTL_CGLMM.stan" # Adaptive BTL-CGLMM
)

precompiled_models <- lapply(stan_model_files, function(file) {
  if (file.exists(file)) {
    stan_model(file, save_dso = TRUE)
  } else {
    stop(paste("Stan model file not found:", file))
  }
})
names(precompiled_models) <- stan_model_files

run_method <- function(method_name, fit_func, target_data,
                       source_data, m, alpha = NULL,
                       iter = 2000,
                       chains = 2,
                       adapt_delta = 0.95,
                       max_treedepth = 10,
                       seed = 2025) {
  cat("\n======== method:", method_name, " ========\n")
  
  params <- list(
    target_data = target_data,
    source_data = source_data,
    m = m,
    iter = iter,
    chains = chains,
    adapt_delta = adapt_delta,
    max_treedepth = max_treedepth
  )
  
  if (!is.null(alpha)) {
    params$alpha <- alpha
  }
  
  if ("seed" %in% names(formals(fit_func))) {
    params$seed <- seed
  }
  
  y <- target_data$y
  fit <- do.call(fit_func, params) 
  log_lik <- rstan::extract(fit, "log_lik")$log_lik
  y_rep <- rstan::extract(fit, "y_rep")$y_rep
  loo_preds <- calculate_loo_preds(log_lik, y_rep)
  a_loo <- calculate_loo_metrics(y, loo_preds)

  data.frame(
    method = method_name,
    deviance = a_loo[["deviance"]],
    R2 = a_loo[["R2"]],
    mse = a_loo[["mse"]],
    mae = a_loo[["mae"]]
  )
}

seed = 2025 + 1
set.seed(seed) 
n = 100        
m = 100     
snr = 0.4
np <- snr * m  
rho_sample = 0.4
# Target data(homogeneous source)
target_data <- generate_target_data_tg(n = n, m = m, snr = snr, rho_sample = rho_sample, seed = seed)
# # Target data(heterogeneous source)
# target_data <- generate_target_data_yg(n = n, m = m, snr = snr, rho_sample = rho_sample, seed = seed)

n_source = 200 
h = 2
sig.delta = 0.5
source_data <- list(
  generate_source_data(
    beta_target = target_data$beta,
    theta = target_data$theta,
    Sigmas = target_data$Sigmas,
    np = np,
    h = h,
    n_source = n_source,
    sig.delta = sig.delta,
    rho_sample = 0.4,
    seed = seed
  )
)

# --- BTL-CGLMM(alpha=0.3) ---
BTL_CGLMM_alpha0.3 <- run_method(
  "BTL_CGLMM_alpha0.3",
  BTL_CGLMM,
  target_data = target_data,
  source_data = source_data,
  m = m,
  alpha = 0.3,
  iter = 2000,
  chains = 2,
  adapt_delta = 0.95,
  max_treedepth = 10,
  seed = seed
)
print(BTL_CGLMM_alpha0.3)

# --- Adaptive BTL-CGLMM ---
Adaptive_BTL_CGLMM <- run_method(
  "Adaptive_BTL_CGLMM",
  Adaptive_BTL_CGLMM,
  target_data = target_data,
  source_data = source_data,
  m = m,
  iter = 2000,
  chains = 2,
  adapt_delta = 0.95,
  max_treedepth = 10,
  seed = seed
)
print(Adaptive_BTL_CGLMM)

